""""""
"""
IMPORTS_________________________________________________________________________________________________________________
"""
import sqlite3 as lite
from datetime import *

from settings import *

"""
FONCTION GENERALES______________________________________________________________________________________________________
"""


# connecte à la BDD, affecte le mode dictionnaire aux résultats de requêtes et renvoie un curseur
def connection_bdd():
    con = lite.connect('BDD.db')
    con.row_factory = lite.Row
    return con


# connecte à la BDD et renvoie les lignes de la table personne dont le prénom commence par la lettre donnée
def selection_personnes_lettre(lettre):
    conn = connection_bdd()
    cur = conn.cursor()
    cur.execute("SELECT nom, prenom, role FROM personnes WHERE prenom LIKE ?", (lettre + "%",))
    lignes = cur.fetchall()
    conn.close()
    return lignes



"""
FONCTION PASSAGE DE COMMANDE____________________________________________________________________________________________
"""


# connecte à la BDD et renvoie toutes les lignes de la table Stock
def selection_pieces():
    conn = connection_bdd()
    cur = conn.cursor()
    cur.execute("SELECT ID, Piece, Quantite FROM Stock")
    #Création de la liste de donnée
    lignes = cur.fetchall()
    conn.close()
    return lignes

#création de la commande
def create_command_bdd(quantities_list):
    #quantities_list se réfere au nombre de pièces commandées pour chaque pièces du catalogue
    con = lite.connect("BDD.db")
    cur = con.cursor()
    #création de la commande
    cur.execute("INSERT INTO Commandes (ETAT, Date) VALUES(?,?)", (command_passed, date()))
    id_part = 0
    id_command = cur.execute("SELECT max(ID) FROM Commandes").fetchall()[0][0]
    print("INFO CONSOLE: Création de la commande numéro {}".format(id_command))
    #ajout de des pièces de la commande dans l'onglet liens
    for quantity in quantities_list:
        id_part += 1
        if quantity != 0:
            print("INFO CONSOLE: Ajout de la pièce {} avec un quantité de {}".format(id_part, quantity))
            cur.execute("INSERT INTO liens (ID_COMMANDE, ID_PIECE, quantite) VALUES (?,?,?)",
                        (id_command, id_part, quantity))
    con.commit()
    con.close()
    print("____________________________________________\n")
    return None

#Nettoyage de la liste des quantitées
def list_clean(list_row):
    list_clean = []
    for i in list_row:
        #vérification de la saisie
        if i.isdigit() == True:
            #ajout d'une quantité
            list_clean.append(int(i))
        else:
            #ajout de 0
            list_clean.append(0)
    return (list_clean)

"""
FONCTION GESTION DES STOCK______________________________________________________________________________________________
"""

# connecte à la BDD et renvoie toutes les lignes de la table Stock
def selection_pieces():
    conn = connection_bdd()
    cur = conn.cursor()
    cur.execute("SELECT ID, Piece, Quantite FROM Stock")
    lignes = cur.fetchall()
    conn.close()
    return lignes

# connecte à la BDD et insère une nouvelle ligne avec les valeurs données dans la table stock
def insertion_stock(ID, Piece, Quantite):
    try:
        conn = connection_bdd()
        cur = conn.cursor()
        cur.execute("INSERT INTO Stock('ID', 'Piece', 'Quantite') VALUES (?,?,?)", (ID, Piece, Quantite))
        conn.commit()
        conn.close()
        return True
    except lite.Error:
        return False


"""
FONCTION GESTION DES COMMANDES__________________________________________________________________________________________
"""

def recuperer_commandes():
    conn = connection_bdd()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Commandes WHERE Commandes.ETAT !={}".format(command_shipped))
    lignes = cur.fetchall()
    conn.close()
    return lignes

def ajout_nvx_stocks(n):
    conn = lite.connect("BDD.db")
    cur = conn.cursor()
    cur.execute("SELECT ID_PIECE, quantite FROM Liens WHERE ID_COMMANDE=(?)",(n,))
    lignes = cur.fetchall()
    conn.close()
    print(lignes)
    for i in range(len(lignes)):
        conn = connection_bdd()
        cur = conn.cursor()
        a=lignes[i][0]
        cur.execute("SELECT Désignation FROM Pieces WHERE ID = (?)",(a,))
        Nom_piece = cur.fetchall()
        L=[n['Désignation'] for n in Nom_piece]
        q = cur.execute("SELECT Quantite FROM Stock WHERE Piece=(?)", (L[0],))
        b = q.fetchall()
        quantity = [n['Quantite'] for n in b]
        if len(quantity)==0:
            quantity = int(lignes[i][1])
            insertion_stock(None,L[0],quantity)
        else:
            quantity = [n['Quantite'] for n in b][0]
            quantity += int(lignes[i][1])
            cur.execute("UPDATE Stock SET Quantite=(?) WHERE Piece=(?)",(quantity,L[0]))
            conn.commit()
    return lignes

def Changer_Etat_Commande(ID_command):
    con = connection_bdd()
    cur = con.cursor()
    cur.execute("UPDATE Commandes SET ETAT = (?) WHERE ID=(?) ", (command_shipped, ID_command))
    con.commit()
    con.close()

def Recevoir_Commande(ID_commande):
    Changer_Etat_Commande(ID_commande)
    ajout_nvx_stocks(ID_commande)
    return None

"""
FONCTIONS AUXILIERES____________________________________________________________________________________________________
"""

#Récupération de la date et l'heure
def date():
    date_row = str(datetime.now()).split(".")
    date = date_row[0]
    return date

