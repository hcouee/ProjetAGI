import sqlite3 as lite

con = lite.connect("BDD.db")
cur = con.cursor()

print(cur.execute("SELECT * FROM Liens").fetchall())