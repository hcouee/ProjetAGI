from flask import Flask, url_for, request, render_template, redirect
import sqlite3 as lite

con = lite.connect('BDD.db')

# ------------------
# application Flask
# ------------------

app = Flask(__name__)

# ---------------------------------------
# les différentes pages (fonctions VUES)
# ---------------------------------------

#Page accueil
@app.route('/')
def accueil():
	return render_template('accueil.html')

#Page AgiLog
@app.route('/AgiLog')
def agilog():
	return render_template('agilog.html')
	
#Page AgiGreen
@app.route('/AgiGreen')
def agigreen():
	return render_template('agigreen.html')

#Page stock
@app.route('/AgiLog/Stock')
def stock():
		
	con = lite.connect('BDD.db')
	con.row_factory = lite.Row
	cur = con.cursor()
	cur.execute("SELECT * FROM Stock")
	lignes = cur.fetchall()
	con.close()
	
	return render_template('stock.html',stock=lignes) 

#Page commande
@app.route('/AgiLog/Commande')
def commande():
		
	con = lite.connect('BDD.db')
	con.row_factory = lite.Row
	cur = con.cursor()
	cur.execute("SELECT * FROM Stock") #Modifier la fin de cette fonction pour insérer dans BDD
	lignes = cur.fetchall()
	con.close()
	
	return render_template('commande.html',stock=lignes) 


if __name__ == '__main__':
	app.run(debug=True, port=5678)
