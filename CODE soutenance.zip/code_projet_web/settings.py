""""""
"""
PARAMETRES 
"""

command_passed = "Envoyée"
command_shipped = "Reçue"