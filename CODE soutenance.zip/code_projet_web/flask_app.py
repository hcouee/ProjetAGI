""""""
"""
IMPORTS ________________________________________________________________________________________________________________
"""
from flask import Flask, url_for, request, render_template, redirect

from fonctions_logiques import *

"""
CREATION DE L'APP_______________________________________________________________________________________________________
"""

app = Flask(__name__)

"""
FONCTIONS DE NAVIGATION__________________________________________________________________________________________________
"""

"""FONCTION GENERALES"""


# renvoie un lien HTML pour retourner à la page index
def retour_index():
    return render_template('accueil.html')


# renvoie un formulaire vers la page cible demandant un prénom (avec une valeur par défaut)
def formulaire_prenom(cible, prenom="entrez votre prénom"):
    formulaire = ""
    formulaire += "<form method='post' action='" + url_for(cible) + "'>"
    formulaire += "<input type='text' name='prenom' value='" + prenom + "'>"
    formulaire += "<input type='submit' value='Envoyer'>"
    formulaire += "</form><br/>"
    return formulaire


"""FONCTION DE PAGES"""


# une page index avec des liens vers les différentes pages d'exemple d'utilisation de Flask
@app.route('/')
def index():
    return render_template('accueil.html')


# une page avec du texte statique
@app.route('/agilog')
def agilog():
    return render_template('agilog.html')


@app.route('/commande')
def commande():
    con = lite.connect('BDD.db')
    con.row_factory = lite.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM Pieces")
    lignes = cur.fetchall()
    con.close()
    # Récupération des quantités sous forme de liste
    entry_row = request.args.getlist('quantity')
    # Nettoyage de la liste des quantités
    part_list = list_clean(entry_row)
    somme = 0
    for i in part_list:
        somme += i
    # vérification que la liste des quantités n'est pas vide
    if somme != 0:
        # création de la commande
        create_command_bdd(part_list)
    return render_template('commande.html', Pieces=lignes)


@app.route('/reception', methods=['GET'])
def reception():
    con = lite.connect('BDD.db')
    con.row_factory = lite.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM Commandes WHERE ETAT != (?)",(command_shipped,))
    lignes = cur.fetchall()
    con.close()
    CommandesAValider = request.args.getlist('etat')  # Liste des IDs des commandes qui ont été livrées
    for ID in CommandesAValider:
        Recevoir_Commande(int(ID))
    return render_template('reception.html', Commandes=lignes)


# une page avec du texte dynamique déterminé par l'URL
@app.route('/agigreen', methods=['GET'])
def agigreen():
    con = lite.connect('BDD.db')
    con.row_factory = lite.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM Liens")
    lignes = cur.fetchall()
    con.close()

    return render_template('agigreen.html', Liens=lignes)

@app.route('/stock', methods=['GET', 'POST'])
def affichage_bdd_stock():
    lignes = selection_pieces()

    conn = connection_bdd()
    cur = conn.cursor()
    initial = 0
    id_ = 0
    if request.method == 'POST':
        desi_piece = request.form["nom_piece_initial"]
        quantite = request.form["Quantite"]

        print(desi_piece)
        print(quantite)

        cur.execute("SELECT ID FROM Stock WHERE Piece =?;", (desi_piece,))
        lignes_initial = cur.fetchall()
        if len(lignes_initial) == 1:
            cur.execute("UPDATE Stock SET Quantite=? WHERE Piece=?;", (quantite, desi_piece))
        elif len(lignes_initial) == 0:
            cur.execute("INSERT INTO Stock (Piece, Quantite) VALUES (?,?);", (desi_piece, quantite))
        else:
            print("problème dans la bdd, 2 lignes avec la même designation")
        conn.commit()
        return redirect(url_for('affichage_bdd_stock'))

    cur.execute("SELECT ID, Désignation FROM Pieces WHERE Désignation !=(?) ORDER BY Désignation ", ("",))
    lignes_initial = cur.fetchall()

    conn.close()
    return render_template('affichage_stock.html', Stock=lignes, commandes_initial=lignes_initial)


@app.route('/ajouter_stock', methods=['GET', 'POST'])
def insertion_bdd_piece_stock():
    erreur = ""
    if request.method == 'POST':

        if (request.form['ID'] != "" and request.form['Piece'] != "" and request.form['Quantite'] != ""):

            res = insertion_stock(request.form['ID'], request.form['Piece'], request.form['Quantite'])

            if (res):

                return redirect(url_for('affichage_bdd_stock'))

            else:
                erreur = "Une erreur a été détectée lors de l'insertion dans la base de données. Veuillez réessayer ou contacter l'administrateur du site."
        else:
            erreur = "Une erreur a été détectée dans le formulaire, merci de remplir tous les champs correctement."

    # on arrive ici si rien n'a été envoyé par POST, ou si la validation des données a échoué

    return render_template('formulaire_personne.html', msg=erreur, nom=request.form.get('ID', ''),
                           prenom=request.form.get('Piece', ''), role=request.form.get('Quantite', ''))


"""
LANCEMENT DE L'APP______________________________________________________________________________________________________
"""

if __name__ == '__main__':
    app.run(debug=True)
